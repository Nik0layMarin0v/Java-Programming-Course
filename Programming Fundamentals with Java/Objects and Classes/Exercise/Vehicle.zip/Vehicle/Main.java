package ObjectsAndClasses.Exercise.Vehicle;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] input = scanner.nextLine().split(" ");
        List<Vehicles> vehiclesList = new ArrayList<>();
        while(!input[0].equals("End")) {
            Vehicles vehicle = new Vehicles();
            vehicle.setType(input[0]);
            vehicle.setModel(input[1]);
            vehicle.setColor(input[2]);
            vehicle.setHorsepower(Integer.parseInt(input[3]));

            vehiclesList.add(vehicle);
            input = scanner.nextLine().split(" ");
        }
        String model = scanner.nextLine();
        int carHorsepowerSum = 0;
        int truckHorsepowerSum = 0;
        int carCounter = 0;
        int truckCounter = 0;
        while (!model.equals("Close the Catalogue")) {
            for (Vehicles vehicle: vehiclesList) {
                if (model.equals(vehicle.getModel())) {
                    System.out.printf("Type: %s%n", vehicle.getType().substring(0, 1).toUpperCase() + vehicle.getType().substring(1));
                    System.out.printf("Model: %s%n", vehicle.getModel());
                    System.out.printf("Color: %s%n", vehicle.getColor());
                    System.out.printf("Horsepower: %d%n", vehicle.getHorsepower());
                }
            }
            model = scanner.nextLine();
        }
        for(Vehicles vehicle: vehiclesList) {
            if (vehicle.getType().equals("car")) {
                carHorsepowerSum += vehicle.getHorsepower();
                carCounter++;
            } else {
                truckHorsepowerSum += vehicle.getHorsepower();
                truckCounter++;
            }
        }
        if (carCounter != 0) {
            System.out.printf("Cars have average horsepower of: %.2f.%n", carHorsepowerSum * 1.0 / carCounter);
        } else {
            System.out.printf("Cars have average horsepower of: %.2f.%n", 0.0);
        }

        if (truckCounter != 0) {
            System.out.printf("Trucks have average horsepower of: %.2f.", truckHorsepowerSum * 1.0 / truckCounter);
        } else {
            System.out.printf("Trucks have average horsepower of: %.2f.", 0.0);
        }

    }
}
