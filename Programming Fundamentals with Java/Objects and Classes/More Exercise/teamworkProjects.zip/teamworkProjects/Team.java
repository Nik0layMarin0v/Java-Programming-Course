package objectsAndClasses.moreExercise.teamworkProjects;

import java.util.List;

public class Team {
    private String team;
    private String creator;
    private List<String> members;

    public Team(String team, String creator, List<String> members) {
        this.team = team;
        this.creator = creator;
        this.members = members;
    }

    public List<String> getMembers() {
        return members;
    }

    public String getTeam() {
        return team;
    }

    public String getCreator() {
        return creator;
    }
}
