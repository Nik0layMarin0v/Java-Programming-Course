package objectsAndClasses.moreExercise.teamworkProjects;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Team> teamList = new ArrayList<>();
        List<Team> disbandTeams = new ArrayList<>();

        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            String input1 = scanner.nextLine();
            String creator = input1.split("-")[0];
            String teamName = input1.split("-")[1];

            boolean registeredTeam = false;
            boolean freeCreator = true;
            for (Team currentTeam: teamList) {
                if (currentTeam.getTeam().equals(teamName)) {
                    registeredTeam = true;
                    System.out.printf("Team %s was already created!%n", teamName);
                }
                if (currentTeam.getCreator().equals(creator)) {
                    freeCreator = false;
                    System.out.printf("%s cannot create another team!%n", creator);
                }
            }
            if (!registeredTeam && freeCreator) {
                Team newTeam = new Team(teamName, creator, new ArrayList<>());
                teamList.add(newTeam);
                System.out.printf("Team %s has been created by %s!%n", teamName, creator);
            }
        }

        String input2 = scanner.nextLine();
        while (!input2.equals("end of assignment")) {
            String member = input2.split("->")[0];
            String teamName = input2.split("->")[1];

            boolean existingTeam = false;
            boolean registeredMember = false;
            for (Team currentTeam: teamList) {
                if (currentTeam.getTeam().equals(teamName)) {
                    existingTeam = true;
                }

                if (currentTeam.getCreator().equals(member)) {
                    registeredMember = true;
                }

                for (String currentMember: currentTeam.getMembers()) {
                    if(member.equals(currentMember)) {
                        registeredMember = true;
                        System.out.printf("Member %s cannot join team %s!%n", member, teamName);
                    }
                }
            }

            if (!existingTeam) {
                System.out.printf("Team %s does not exist!%n", teamName);
            } else if (registeredMember) {
                System.out.printf("Member %s cannot join team %s!%n", member, teamName);
            }
            if (!registeredMember) {
                for (Team currentTeam: teamList) {
                    if (currentTeam.getTeam().equals(teamName)) {
                        currentTeam.getMembers().add(member);
                    }
                }
            }

            input2 = scanner.nextLine();
        }

        for (int i = 0; i < teamList.size(); i++){
            Team currentTeam = teamList.get(i);
            if (currentTeam.getMembers().size() < 1) {
                disbandTeams.add(currentTeam);
                teamList.remove(currentTeam);
                i = -1;
            }
        }

        Collections.sort(teamList, new Comparator<Team>() {
            @Override
            public int compare(Team o1, Team o2) {
                return o1.getTeam().compareTo(o2.getTeam());
            }
        });
        for (Team currentTeam: teamList){
            String currentTeamName = currentTeam.getTeam();
            String currentCreator = currentTeam.getCreator();
            List<String> currentMembers = currentTeam.getMembers();

            Collections.sort(currentMembers);
            System.out.println(currentTeamName);
            System.out.println("- " + currentCreator);

            for (int i = 0; i < currentMembers.size(); i++) {
                System.out.println("-- " + currentMembers.get(i));
            }
        }

        System.out.println("Teams to disband:");
        Collections.sort(disbandTeams, new Comparator<Team>() {
            @Override
            public int compare(Team o1, Team o2) {
                return o1.getTeam().compareTo(o2.getTeam());
            }
        });
        for (int i = 0; i < disbandTeams.size(); i++) {
            String name = disbandTeams.get(i).getTeam();
            System.out.println(name);
        }
    }
}
