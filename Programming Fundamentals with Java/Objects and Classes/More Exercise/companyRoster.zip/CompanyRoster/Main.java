package objectsAndClasses.moreExercise.CompanyRoster;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        List<Employee> employeesList = new ArrayList<>();
        Map<String, List<Employee>> departments = new HashMap<>();

        for (int i = 0; i < n; i++) {
            String[] dataArr = scanner.nextLine().split(" ");
            String name = dataArr[0];
            double salary = Double.parseDouble(dataArr[1]);
            String position = dataArr[2];
            String department = dataArr[3];

            Employee currEmployee = new Employee(name, salary, position, department);
            if (dataArr.length == 6) {
                currEmployee.setEmail(dataArr[4]);
                currEmployee.setAge(Integer.parseInt(dataArr[5]));
            } else if (dataArr.length == 5) {
                if (dataArr[4].contains("@")) {
                    currEmployee.setEmail(dataArr[4]);
                } else {
                    currEmployee.setAge(Integer.parseInt(dataArr[4]));
                }
            }

            if (!departments.containsKey(department)) {
                departments.put(department, new ArrayList<>());
            }
            departments.get(department).add(currEmployee);

        }

        departments.entrySet().stream().sorted((a, b) -> {
            double avrFirst = a.getValue().stream().mapToDouble(Employee::getSalary).average().orElse(Double.NaN);
            double avrSecond = b.getValue().stream().mapToDouble(Employee::getSalary).average().orElse(Double.NaN);
            return Double.compare(avrSecond, avrFirst);

        }).limit(1).forEach(e -> {
            System.out.println(String.format("Highest Average Salary: %s", e.getKey()));
            e.getValue().stream().sorted((a, b) -> Double.compare(b.getSalary(), a.getSalary())).forEach(o -> System.out.println(String.format("%s %.2f %s %d", o.getName(), o.getSalary(), o.getEmail(), o.getAge())));
        });


    }
}
