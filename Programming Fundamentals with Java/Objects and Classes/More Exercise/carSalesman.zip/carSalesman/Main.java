package objectsAndClasses.moreExercise.carSalesman;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Engine> enginesList = new ArrayList<>();

        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            String[] input1 = scanner.nextLine().split(" ");
            String model = input1[0];
            String power = input1[1];

            Engine newEngine = new Engine(model, power);
            if (input1.length == 3) {
                if (input1[2].charAt(0) > 64 && input1[2].charAt(0) < 91) {
                    newEngine.setEfficiency(input1[2]);
                } else {
                    newEngine.setDisplacement(input1[2]);
                }
            } else if (input1.length == 4) {
                newEngine.setDisplacement(input1[2]);
                newEngine.setEfficiency(input1[3]);
            }

            enginesList.add(newEngine);
        }

        List<Car> carList = new ArrayList<>();
        int m = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < m; i++) {
            String[] input2 = scanner.nextLine().split(" ");
            String carModel = input2[0];
            String engineModel = input2[1];
            Engine currentEngine = new Engine("d", "d");
            for (Engine engine: enginesList) {
                if (engineModel.equals(engine.getModel())) {
                    currentEngine = engine;
                }
            }
            Car currentCar = new Car(carModel, currentEngine);

            if (input2.length == 3) {
                if (input2[2].charAt(0) >= '0' && input2[2].charAt(0) <= '9') {
                    currentCar.setWeight(input2[2]);
                } else {
                    currentCar.setColor(input2[2]);
                }
            } else if (input2.length == 4) {
                currentCar.setWeight(input2[2]);
                currentCar.setColor(input2[3]);
            }

            carList.add(currentCar);
        }

        for (Car car: carList) {
            car.printing();
        }
    }
}
